/* % $Header: /usr/local/cvsroot/designs/rueck_werte.h,v 1.2 1997/09/03 13:33:13 alfred Exp $ */
/******************************************************************************/
/*                                                                            */
/*    		K O N S T A N T E N D E F I N I T I O N E N		      */
/*									      */
/******************************************************************************/


# define	regulaerer_Durchlauf		0
# define	zu_wenig_Speicherplatz		1
# define	lin_abh_Vektoren		2
# define	Matrix_zu_klein			3
