// xdclass.h wrapper

